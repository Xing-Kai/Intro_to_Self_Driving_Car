#ifndef initialize_matrix_hpp
#define initialize_matrix_hpp

#include <vector>
std::vector < std::vector<int> > initialize_matrix(int num_rows, int num_cols, int initial_value);
#endif /* initialize_matrix_hpp */
