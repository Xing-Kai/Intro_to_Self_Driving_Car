#ifndef print_hpp
#define print_hpp

#include <iostream>
#include <vector>

void print(std::vector< std::vector<float> > matrix);

#endif /* print_hpp */

