#ifndef print_hpp
#define print_hpp

#include <iostream>
#include <vector>

void print(std::vector< std::vector<int> > matrix);

#endif /* print_hpp */
