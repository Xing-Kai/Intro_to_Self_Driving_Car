#ifndef scalar_multiply_hpp
#define scalar_multiply_hpp

#include <vector>

std::vector< std::vector<int> > scalar_multiply(std::vector< std::vector<int> > matrix, int scalar);

#endif /* scalar_multiply_hpp */
