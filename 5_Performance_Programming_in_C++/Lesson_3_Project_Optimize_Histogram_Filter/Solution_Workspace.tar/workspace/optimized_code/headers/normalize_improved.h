#ifndef NORMALIZE_IMPROVED_H
#define NORMALIZE_IMPROVED_H

#include <vector>

std::vector < std::vector <float> > normalize_improved(std::vector < std::vector <float> > &grid);

#endif /* NORMALIZE_IMPROVED.H */